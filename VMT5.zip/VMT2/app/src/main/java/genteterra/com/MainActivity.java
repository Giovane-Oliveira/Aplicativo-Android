package genteterra.com;

import android.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.view.*;
import android.content.*;


public class MainActivity extends AppCompatActivity {

    private EditText edtlogin, edtpasswd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtlogin = findViewById(R.id.edt1);
        edtpasswd =  findViewById(R.id.edt2);
        Button btnok = findViewById(R.id.bnt1);

            btnok.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    // Recuperando Valores
                    final  String V2 = edtlogin.getText().toString();
                    final String V1 = edtpasswd.getText().toString();

                    if (V2.trim().isEmpty() || V1.trim().isEmpty()) {

                        AlertDialog.Builder dig;
                        dig = new AlertDialog.Builder(MainActivity.this);
                        dig.setMessage("Preencha os campos");
                        dig.setNeutralButton("ok", null);
                        dig.show();
                    } else {
                        Intent it = new Intent(MainActivity.this, Form.class);
                        startActivity(it);
                    }
                }
            });
    }

}
