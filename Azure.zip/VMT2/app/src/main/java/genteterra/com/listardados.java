package genteterra.com;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;


public class listardados extends AppCompatActivity {
    ListView vmt;
    Cursor cr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listardados);
        vmt = findViewById(R.id.listvmt);

        AdminSqlLite admin = new AdminSqlLite(this, "adm", null, 1);
        SQLiteDatabase db = admin.getWritableDatabase();
        cr = db.rawQuery("select * from usuario", null);
        ArrayList<String> al = new ArrayList<>();
        ListAdapter la=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,al);
        vmt.setAdapter(la);
        if (cr.moveToFirst()){
            do{
                al.add("id: "+ cr.getString(0));
                al.add("nome: " + cr.getString(1));
                al.add("senha: " + cr.getString(2));

            }while(cr.moveToNext());
            if(db!=null){
                db.close();
            }
        }

    }
}


