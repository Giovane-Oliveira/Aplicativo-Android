package genteterra.com;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class form1 extends AppCompatActivity {
private Button proximo, voltar;
private EditText lacre1, lacre2, antAmp1, antAmp2, antSat1, antSat2, chicote1, chicote2, interface1, interface2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form1);
        proximo = findViewById(R.id.btnform1);
        voltar = findViewById(R.id.btnform12);
        lacre1 = findViewById(R.id.lacreentrada);
        lacre2 = findViewById(R.id.lacresaida);
        antAmp1 = findViewById(R.id.antampentrada);
        antAmp2 = findViewById(R.id.antampsaida);
        antSat1 = findViewById(R.id.antsatentrada);
        antSat2 = findViewById(R.id.antsatsaida);
        chicote1 = findViewById(R.id.chicoteen);
        chicote2 = findViewById(R.id.chicotesai);
        interface1 = findViewById(R.id.interfaceen);
        interface2 = findViewById(R.id.interfacesai);



        proximo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(form1.this, form2.class);
                startActivity(it);
            }
        });

        voltar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(form1.this, Form.class);
                startActivity(it);
            }
        });
    }
}
