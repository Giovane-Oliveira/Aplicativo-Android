package genteterra.com;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class form3 extends AppCompatActivity {
private Button proximo, voltar;
private EditText condsys, visita, respdraga, kmrd, deslocamento, pagamento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form3);

        proximo = findViewById(R.id.btnform3);
        voltar = findViewById(R.id.btnform32);
        condsys = findViewById(R.id.condsys);
        visita = findViewById(R.id.visita);
        respdraga = findViewById(R.id.respdraga);
        kmrd = findViewById(R.id.km);
        deslocamento = findViewById(R.id.desloc);
        pagamento = findViewById(R.id.pag);

        proximo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(form3.this, form4.class);
                startActivity(it);
            }
        });

        voltar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(form3.this, form2.class);
                startActivity(it);
            }
        });
    }
    }

