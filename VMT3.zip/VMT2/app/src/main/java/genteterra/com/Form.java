package genteterra.com;

import android.app.AlertDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class Form extends AppCompatActivity {
    private EditText txt1, txt2, txt3, txt4;
    private Button proximo, voltar;
    private Spinner spinner1, spinner2, spinner3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);
        proximo =  findViewById(R.id.btnproximo);
        voltar =  findViewById(R.id.btnvoltar);
        txt1 = findViewById(R.id.edtform1_0);
        txt2 = findViewById(R.id.edtform1_1);
        txt3 = findViewById(R.id.edtform1_2);
        txt4 = findViewById(R.id.edtform1_3);
        spinner1 = findViewById(R.id.spinner1);
        spinner2 =  findViewById(R.id.spinner2);
        spinner3 = findViewById(R.id.spinner3);

        //Selecao de dragas spinner1
        ArrayAdapter adapter = ArrayAdapter.createFromResource(this,
                R.array.Dragas, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);

        //selecao de empresas spinner2
        ArrayAdapter adapter1 = ArrayAdapter.createFromResource(this,
                R.array.Empresas, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter1);

        //selecao mineradoras spinner3
        ArrayAdapter adapter2 = ArrayAdapter.createFromResource(this,
                R.array.Mineradoras, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3.setAdapter(adapter2);


        //Recuperando valores dragas, empresas, mineradoras
        String item = spinner1.getSelectedItem().toString();
        String item1 = spinner2.getSelectedItem().toString();
        String item2 = spinner3.getSelectedItem().toString();

        proximo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(Form.this, form1.class);
                startActivity(it);
            }
        });

        voltar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(Form.this, MainActivity.class);
                startActivity(it);
            }
        });


    }
}
