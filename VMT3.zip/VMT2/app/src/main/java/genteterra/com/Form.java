package genteterra.com;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Form extends AppCompatActivity {
    private EditText txt1, txt2, txt3, txt4;
    private Button proximo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);
        proximo =  findViewById(R.id.btnproximo);
        txt1 = findViewById(R.id.edtform1_0);
        txt2 = findViewById(R.id.edtform1_1);
        txt3 = findViewById(R.id.edtform1_2);
        txt4 = findViewById(R.id.edtform1_3);


        proximo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(Form.this, form1.class);
                startActivity(it);
            }
        });


    }
}
