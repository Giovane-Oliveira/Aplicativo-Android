package genteterra.com;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class form2 extends AppCompatActivity {
private Button proximo, voltar;
private EditText term1, term2, voltagem, comunicador, antsatelital, script, antgprs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form2);
        proximo = findViewById(R.id.btnform2);
        voltar = findViewById(R.id.btnform21);
        term1 = findViewById(R.id.termentrada);
        term2 = findViewById(R.id.termsaida);
        voltagem = findViewById(R.id.voltagem);
        comunicador = findViewById(R.id.comunicador);
        antsatelital = findViewById(R.id.antsatelital);
        script = findViewById(R.id.script);
        antgprs = findViewById(R.id.gprs);



        proximo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(form2.this, form3.class);
                startActivity(it);
            }
        });
        voltar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(form2.this, form1.class);
                startActivity(it);
            }
        });
    }
}
