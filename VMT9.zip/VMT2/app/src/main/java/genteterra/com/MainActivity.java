package genteterra.com;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.view.*;
import android.content.*;


public class MainActivity extends AppCompatActivity {
    private EditText edtlogin, edtpasswd;
    private String user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtlogin = findViewById(R.id.edt1);
        edtpasswd = findViewById(R.id.edt2);
        //Button btnok = findViewById(R.id.bnt1);
         //CheckBox check = findViewById(R.id.lembrar);

    }

        //metodo de ingreso
        public void validarusuario (View v){
            final String V2 = edtlogin.getText().toString();
            final String V1 = edtpasswd.getText().toString();

            if (V2.trim().isEmpty() || V1.trim().isEmpty()) {

                AlertDialog.Builder dig;
                dig = new AlertDialog.Builder(MainActivity.this);
                dig.setMessage("Preencha os campos");
                dig.setNeutralButton("ok", null);
                dig.show();
            } else {
                AdminSqlLite admin = new AdminSqlLite(this, "Usuarios", null, 1);
                SQLiteDatabase db = admin.getWritableDatabase();
                String usuario = edtlogin.getText().toString();
                String senha = edtpasswd.getText().toString();



                @SuppressLint("Recycle") Cursor fila = db.rawQuery("select nome,senha from usuario where nome='" + usuario + "' and senha='" + senha + "'", null);
                //preguntamos si el cursor tiene algun valor almacenado
                if (fila.moveToFirst()) {
                    //capturamos los valores del cursos y lo almacenamos en variable
                    String usua = fila.getString(0);
                    String pass = fila.getString(1);
                    //preguntamos si los datos ingresados son iguales
                    if (usuario.equals(usua) && senha.equals(pass)) {
                        //si son iguales entonces vamos a otra ventana
                        //Menu es una nueva actividad empty
                        Intent vem = new Intent(this, Form.class);
                        vem.putExtra("login", usua);
                        startActivity(vem);
                        //limpiamos las las cajas de texto
                        edtlogin.setText("");
                        edtpasswd.setText("");


                    }
                } else {

                    Toast.makeText(this, "Login ou senha inválido!", Toast.LENGTH_SHORT).show();


                }
            }
        }

    }
