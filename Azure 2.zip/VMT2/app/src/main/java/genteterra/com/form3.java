package genteterra.com;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
//####################################################################################Microsoft###################################################################################
import com.microsoft.windowsazure.mobileservices.MobileServiceClient;
import com.microsoft.windowsazure.mobileservices.MobileServiceList;
import com.microsoft.windowsazure.mobileservices.http.OkHttpClientFactory;
import com.microsoft.windowsazure.mobileservices.table.query.Query;
import com.microsoft.windowsazure.mobileservices.table.sync.MobileServiceSyncContext;
import com.microsoft.windowsazure.mobileservices.table.sync.MobileServiceSyncTable;
import com.microsoft.windowsazure.mobileservices.table.sync.localstore.ColumnDataType;
import com.microsoft.windowsazure.mobileservices.table.sync.localstore.MobileServiceLocalStoreException;
import com.microsoft.windowsazure.mobileservices.table.sync.localstore.SQLiteLocalStore;
import com.microsoft.windowsazure.mobileservices.table.sync.synchandler.SimpleSyncHandler;
import com.squareup.okhttp.OkHttpClient;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

//####################################################################################Microsoft###################################################################################


public class form3 extends AppCompatActivity {
    //####################################################################################Microsoft###################################################################################
    private Query mPullQuery;


    ArrayList<ToDoItem> mAdapter;


    /**
     * Client reference
     */
    private MobileServiceClient mClient;

    /**
     * Table used to access data from the mobile app backend.
     */
   // private MobileServiceTable<ToDoItem> mToDoTable;

    //Offline Sync
    /**
     * Table used to store data locally sync with the mobile app backend.
     */
    private MobileServiceSyncTable<ToDoItem> mToDoTable;




    /**
     * Initializes the activity
     */



//####################################################################################Microsoft###################################################################################


    private String term1;
    private String term2;
    private String voltagem;
    private String comunicador;
    private String antsatelital;
    private String script;
    private String antgprs;
    private String data;
    private String horainicio;
    private String horafim;
    private String pontoref;
    private String id;
    private String lacre1;
    private String lacre2;
    private String antAmp1;
    private String antAmp2;
    private String antSat1;
    private String antSat2;
    private String chicote1;
    private String chicote2;
    private String interface1;
    private String interface2;
    private String login;
    private String draga;
    private String empresa;
    private String mineradoras;
    private String problema;
    private String solucao;
    private String observacao;


    private int count;

    private EditText condsys1, visita1, respdraga1, kmrd1, deslocamento1, pagamento1;

    public String getTerm1() {
        return term1;
    }

    public void setTerm1(String term1) {
        this.term1 = term1;
    }

    public String getTerm2() {
        return term2;
    }

    public void setTerm2(String term2) {
        this.term2 = term2;
    }

    public String getVoltagem() {
        return voltagem;
    }

    public void setVoltagem(String voltagem) {
        this.voltagem = voltagem;
    }

    public String getComunicador() {
        return comunicador;
    }

    public void setComunicador(String comunicador) {
        this.comunicador = comunicador;
    }

    public String getAntsatelital() {
        return antsatelital;
    }

    public void setAntsatelital(String antsatelital) {
        this.antsatelital = antsatelital;
    }

    public String getScript() {
        return script;
    }

    public void setScript(String script) {
        this.script = script;
    }

    public String getAntgprs() {
        return antgprs;
    }

    public void setAntgprs(String antgprs) {
        this.antgprs = antgprs;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHorainicio() {
        return horainicio;
    }

    public void setHorainicio(String horainicio) {
        this.horainicio = horainicio;
    }

    public String getHorafim() {
        return horafim;
    }

    public void setHorafim(String horafim) {
        this.horafim = horafim;
    }

    public String getPontoref() {
        return pontoref;
    }

    public void setPontoref(String pontoref) {
        this.pontoref = pontoref;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLacre1() {
        return lacre1;
    }

    public void setLacre1(String lacre1) {
        this.lacre1 = lacre1;
    }

    public String getLacre2() {
        return lacre2;
    }

    public void setLacre2(String lacre2) {
        this.lacre2 = lacre2;
    }

    public String getAntAmp1() {
        return antAmp1;
    }

    public void setAntAmp1(String antAmp1) {
        this.antAmp1 = antAmp1;
    }

    public String getAntAmp2() {
        return antAmp2;
    }

    public void setAntAmp2(String antAmp2) {
        this.antAmp2 = antAmp2;
    }

    public String getAntSat1() {
        return antSat1;
    }

    public void setAntSat1(String antSat1) {
        this.antSat1 = antSat1;
    }

    public String getAntSat2() {
        return antSat2;
    }

    public void setAntSat2(String antSat2) {
        this.antSat2 = antSat2;
    }

    public String getChicote1() {
        return chicote1;
    }

    public void setChicote1(String chicote1) {
        this.chicote1 = chicote1;
    }

    public String getChicote2() {
        return chicote2;
    }

    public void setChicote2(String chicote2) {
        this.chicote2 = chicote2;
    }

    public String getInterface1() {
        return interface1;
    }

    public void setInterface1(String interface1) {
        this.interface1 = interface1;
    }

    public String getInterface2() {
        return interface2;
    }

    public void setInterface2(String interface2) {
        this.interface2 = interface2;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getDraga() {
        return draga;
    }

    public void setDraga(String draga) {
        this.draga = draga;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public String getMineradoras() {
        return mineradoras;
    }

    public void setMineradoras(String mineradoras) {
        this.mineradoras = mineradoras;
    }

    public String getProblema() {
        return problema;
    }

    public void setProblema(String problema) {
        this.problema = problema;
    }

    public String getSolucao() {
        return solucao;
    }

    public void setSolucao(String solucao) {
        this.solucao = solucao;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form3);
        Button finalizar = findViewById(R.id.button);
        Button voltar = findViewById(R.id.btnform32);
        condsys1 = findViewById(R.id.condsys);
        visita1 = findViewById(R.id.visita);
        respdraga1 = findViewById(R.id.respdraga);
        kmrd1 = findViewById(R.id.km);
        deslocamento1 = findViewById(R.id.desloc);
        pagamento1 = findViewById(R.id.pag);


        //recuperando objeto do tipo pacote
        Bundle bundle = getIntent().getExtras();
        assert bundle != null;
        setId(bundle.getString("ID"));
        setLogin(bundle.getString("LOGIN"));
        setDraga(bundle.getString("DRAGA"));
        setEmpresa(bundle.getString("EMPRESA"));
        setMineradoras(bundle.getString("MINERADORA"));
        setData(bundle.getString("DATA"));
        setHorainicio(bundle.getString("HRINICIO"));
        setHorafim(bundle.getString("HRFIM"));
        setPontoref(bundle.getString("PONTOREF"));
        setProblema(bundle.getString("PROBLEMA"));
        setSolucao(bundle.getString("SOLUCAO"));
        setObservacao(bundle.getString("OBS"));
        setLacre1(bundle.getString("LACRE1"));
        setLacre2(bundle.getString("LACRE2"));
        setAntAmp1(bundle.getString("ANTAMP1"));
        setAntAmp2(bundle.getString("ANTAMP2"));
        setAntSat1(bundle.getString("ANTSAT1"));
        setAntSat2(bundle.getString("ANTSAT2"));
        setChicote1(bundle.getString("CHICOTE1"));
        setChicote2(bundle.getString("CHICOTE2"));
        setInterface1(bundle.getString("INTERFACE1"));
        setInterface2(bundle.getString("INTERFACE2"));
        setTerm1(bundle.getString("TERM1"));
        setTerm2(bundle.getString("TERM2"));
        setVoltagem(bundle.getString("VOLTAGEM"));
        setComunicador(bundle.getString("COMUNICADOR"));
        setAntsatelital(bundle.getString("ANTSATELITAL"));
        setScript(bundle.getString("SCRIPT"));
        setAntgprs(bundle.getString("ANTGPRS"));






        //####################################################################################Microsoft###################################################################################
// JPM Inserção AzureServiceAdapter.Initialize(this);

        //AzureServiceAdapter.Initialize(this);

        try {
            // Create the client instance, using the provided mobile app URL.
            mClient = new MobileServiceClient(
                    "https://vmtandroid.azurewebsites.net",
                    this);

            // Extend timeout from default of 10s to 20s
            mClient.setAndroidHttpClientFactory(new OkHttpClientFactory() {
                @Override
                public OkHttpClient createOkHttpClient() {
                    OkHttpClient client = new OkHttpClient();
                    client.setReadTimeout(20, TimeUnit.SECONDS);
                    client.setWriteTimeout(20, TimeUnit.SECONDS);
                    return client;
                }
            });

            mPullQuery = mClient.getTable(ToDoItem.class).where().field("complete").eq(false);

            // Get the remote table instance to use.
            //mToDoTable = mClient.getTable(ToDoItem.class);

            // Offline sync table instance.
            mToDoTable = mClient.getSyncTable("ToDoItem", ToDoItem.class);

            //Init local storage
            initLocalStore().get();


            voltar.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    finish();
                }
            });

            finalizar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent it = new Intent(form3.this, MainActivity.class);
                    startActivity(it);
                    addItem();
                    if(isNetworkAvailable()){

                        sync();
                        refreshItemsFromTable();

                    }
                }
            });


        } catch (MalformedURLException e) {
            createAndShowDialog(new Exception("There was an error creating the Mobile Service. Verify the URL"), "Error");
        } catch (Exception e) {
            createAndShowDialog(e, "Error");
        }

//####################################################################################Microsoft###################################################################################



    }

    //####################################################################################Microsoft###################################################################################



    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager;
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
    public void addItem() {
        if (mClient == null) {
            return;
        }

        // Create a new item
        final ToDoItem item = new ToDoItem();
        item.setText("teste");
        item.setComplete(false);


        // Insert the new item
        @SuppressLint("StaticFieldLeak") AsyncTask<Void, Void, Void> task = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                try {
                    final ToDoItem entity = addItemInTable(item);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!entity.isComplete()) {
                                mAdapter = new ArrayList<ToDoItem>();
                                mAdapter.add(entity);
                                Toast.makeText(form3.this, "O vmt foi lançado com sucesso!", Toast.LENGTH_SHORT).show();

                            }
                        }
                    });
                } catch (final Exception e) {
                    createAndShowDialogFromTask(e, "Error");
                }
                return null;
            }
        };

        runAsyncTask(task);
        limpardados();

    }

    /**
     * Add an item to the Mobile Service Table
     *
     * @param item The item to Add
     */
    public ToDoItem addItemInTable(ToDoItem item) throws ExecutionException, InterruptedException {
        ToDoItem entity = mToDoTable.insert(item).get();
        return entity;
    }

    private void refreshItemsFromTable() {

        // Get the items that weren't marked as completed and add them in the
        // adapter

        @SuppressLint("StaticFieldLeak") AsyncTask<Void, Void, Void> task = new AsyncTask<Void, Void, Void>(){
            @Override
            protected Void doInBackground(Void... params) {

                try {
                    //final List<ToDoItem> results = refreshItemsFromMobileServiceTable();

                    //Offline Sync
                    //final List<ToDoItem> results = refreshItemsFromMobileServiceTableSyncTable();
                    final MobileServiceList<ToDoItem> results = mToDoTable.read(mPullQuery).get();


                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mAdapter.clear();

                            for (ToDoItem item : results) {
                                mAdapter.add(item);
                            }
                        }
                    });
                } catch (final Exception e){
                    createAndShowDialogFromTask(e, "Error");
                }

                return null;
            }
        };

        runAsyncTask(task);
    }


    private AsyncTask<Void, Void, Void> initLocalStore() throws MobileServiceLocalStoreException, ExecutionException, InterruptedException {

        @SuppressLint("StaticFieldLeak") AsyncTask<Void, Void, Void> task = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                try {

                    MobileServiceSyncContext syncContext = mClient.getSyncContext();

                    if (syncContext.isInitialized())
                        return null;
                    SQLiteLocalStore localStore = new SQLiteLocalStore(mClient.getContext(), "OfflineStore", null, 1);
                    Map<String, ColumnDataType> tableDefinition = new HashMap<String, ColumnDataType>();
                    tableDefinition.put("id", ColumnDataType.String);
                    tableDefinition.put("text", ColumnDataType.String);
                    tableDefinition.put("complete", ColumnDataType.Boolean);


                    localStore.defineTable("ToDoItem", tableDefinition);

                    SimpleSyncHandler handler = new SimpleSyncHandler();

                    syncContext.initialize(localStore, handler).get();

                } catch (final Exception e) {
                    createAndShowDialogFromTask(e, "Error");
                }

                return null;
            }
        };

        return runAsyncTask(task);
    }

    //Offline Sync
    /**
     * Sync the current context and the Mobile Service Sync Table
     * @return
     */

    @SuppressLint("StaticFieldLeak")
    public void sync(){
        if (isNetworkAvailable()) {
            new AsyncTask<Void, Void, Void>() {

                @Override
                protected Void doInBackground(Void... params) {
                    try {
                        mClient.getSyncContext().push().get();
                        mToDoTable.pull(mPullQuery).get();

                    } catch (Exception exception) {
                        createAndShowDialog(exception, "Error");
                    }
                    return null;
                }
            }.execute();
        } else {
            Toast.makeText(this, "You are not online, re-sync later!" +
                    "", Toast.LENGTH_LONG).show();
        }
    }


    /**
     * Creates a dialog and shows it
     *
     * @param exception The exception to show in the dialog
     * @param title     The dialog title
     */
    private void createAndShowDialogFromTask(final Exception exception, String title) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                createAndShowDialog(exception, "Error");
            }
        });
    }


    /**
     * Creates a dialog and shows it
     *
     * @param exception The exception to show in the dialog
     * @param title     The dialog title
     */
    private void createAndShowDialog(Exception exception, String title) {
        Throwable ex = exception;
        if (exception.getCause() != null) {
            ex = exception.getCause();
        }
        createAndShowDialog(ex.getMessage(), title);
    }

    /**
     * Creates a dialog and shows it
     *
     * @param message The dialog message
     * @param title   The dialog title
     */
    private void createAndShowDialog(final String message, final String title) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage(message);
        builder.setTitle(title);
        builder.create().show();
    }

    /**
     * Run an ASync task on the corresponding executor
     *
     * @param task
     * @return
     */
    private AsyncTask<Void, Void, Void> runAsyncTask(AsyncTask<Void, Void, Void> task) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            return task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        } else {
            return task.execute();
        }
    }



    //####################################################################################Microsoft###################################################################################

    public void limpardados(){

       setId("");
       setLogin("");
       setDraga("");
       setEmpresa("");
       setMineradoras("");
       setData("");
       setHorainicio("");
       setHorafim("");
       setPontoref("");
       setProblema("");
       setSolucao("");
       setObservacao("");
       setLacre1("");
       setLacre2("");
        setAntAmp1("");
        setAntAmp2("");
        setAntSat1("");
        setAntSat2("");
        setChicote1("");
        setChicote2("");
        setInterface1("");
        setInterface2("");
        setTerm1("");
        setTerm2("");
        setVoltagem("");
        setComunicador("");
        setAntsatelital("");
        setScript("");
        setAntgprs("");
     condsys1.setText("");
       visita1.setText("");
      respdraga1.setText("");
       kmrd1.setText("");
       deslocamento1.setText("");
        pagamento1.setText("");
    }


    }



